---
name: Feature request
about: Suggest a feature for nginx
title: ""
labels: "feature"
---

### Describe the feature you'd like to add to nginx

A clear and concise description of the feature.

### Describe the problem this feature solves

A clear and concise description of the problem.

### Additional context

Add any other context about the feature request here.
